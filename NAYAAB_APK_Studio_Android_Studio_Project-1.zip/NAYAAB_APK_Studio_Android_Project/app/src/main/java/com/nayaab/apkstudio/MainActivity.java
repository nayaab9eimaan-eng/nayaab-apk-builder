package com.nayaab.apkstudio;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.database.Cursor;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Environment;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 26, 53));
        getWindow().setNavigationBarColor(Color.rgb(16, 26, 53));
        buildWebView();
    }

    private void buildWebView() {
        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new NativeFiles(), "NayaabNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if ("file".equalsIgnoreCase(scheme) && uri.toString().startsWith("file:///android_asset/")) {
                    return false;
                }
                if ("mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)
                        || "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installBlobDownloadBridge();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Unable to open file picker.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                // Standard network downloads can be handed to Android's browser/download manager.
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Use the page's Download button. Blob downloads are saved to Downloads.", Toast.LENGTH_LONG).show();
                }
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void installBlobDownloadBridge() {
        String script = "(function(){if(window.__nayaabBlobBridgeInstalled)return;window.__nayaabBlobBridgeInstalled=true;" +
                "document.addEventListener('click',function(ev){var a=ev.target&&ev.target.closest?ev.target.closest('a'):null;" +
                "if(!a||!a.href||!a.href.startsWith('blob:'))return;ev.preventDefault();ev.stopImmediatePropagation();" +
                "var name=a.download||'nayaab-download.bin';fetch(a.href).then(function(r){return r.blob()}).then(function(b){" +
                "var reader=new FileReader();reader.onloadend=function(){var s=String(reader.result||'');var comma=s.indexOf(',');" +
                "if(comma>=0)window.NayaabNative.saveBase64(name,s.substring(comma+1),b.type||'application/octet-stream');};reader.readAsDataURL(b);" +
                "}).catch(function(){alert('Could not prepare the download. Please try again.');});},true);})();";
        webView.evaluateJavascript(script, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
                else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private class NativeFiles {
        @JavascriptInterface
        public void saveBase64(String filename, String base64, String mimeType) {
            runOnUiThread(() -> {
                try {
                    String safeName = filename == null ? "nayaab-download.bin" : filename.replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (safeName.trim().isEmpty()) safeName = "nayaab-download.bin";
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    Uri item;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NAYAAB APK Studio");
                        item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    } else {
                        java.io.File folder = new java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "NAYAAB APK Studio");
                        if (!folder.exists() && !folder.mkdirs()) throw new IOException("Could not create downloads folder");
                        java.io.File output = new java.io.File(folder, safeName);
                        try (java.io.FileOutputStream out = new java.io.FileOutputStream(output)) { out.write(bytes); }
                        Toast.makeText(MainActivity.this, "Saved to app Downloads: " + output.getAbsolutePath(), Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (item == null) throw new IOException("Could not create download file");
                    try (OutputStream out = getContentResolver().openOutputStream(item)) {
                        if (out == null) throw new IOException("Could not open download file");
                        out.write(bytes);
                    }
                    Toast.makeText(MainActivity.this, "Saved to Downloads/NAYAAB APK Studio", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Download failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("NayaabNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
