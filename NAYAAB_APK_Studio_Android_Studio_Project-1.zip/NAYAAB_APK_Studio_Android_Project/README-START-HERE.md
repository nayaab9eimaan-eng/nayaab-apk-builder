# NAYAAB APK Studio — Android Studio Project

This is an Android WebView wrapper around the NAYAAB APK Studio HTML interface.

## What is included
- Android app source (Java)
- HTML converter packaged at `app/src/main/assets/www/index.html`
- Android file picker support for HTML/ZIP/icon uploads
- Native download bridge for blob-generated files, saved to `Downloads/NAYAAB APK Studio`
- Internet permission for the converter's JSZip CDN and configured cloud API
- Gradle project files

## Open and build
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `NAYAAB_APK_Studio_Android_Project` folder.
4. Let Gradle sync. Use JDK 17 and install Android SDK Platform 35 if prompted. If Android Studio asks which Gradle distribution to use, select its Gradle wrapper configuration for Gradle 8.9 or use a local Gradle 8.9 installation.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When complete, Android Studio will show a link to the debug APK. The usual output is `app/build/outputs/apk/debug/app-debug.apk`.

## Important: cloud building is not live yet
The packaged HTML currently contains this placeholder:
`https://YOUR-WORKER.workers.dev`

That means the converter interface opens in the app, but its automatic cloud APK build will report that the cloud backend is not configured until the site owner deploys the Cloudflare Worker and sets the real API URL in `app/src/main/assets/www/index.html`. The app wrapper itself does not compile APKs; it displays the converter and connects to the separate cloud backend.

## Notes
- Minimum Android version: Android 8.0 (API 26).
- The included build type is a debug APK for testing. It is not a Play Store-signed release.
- Gradle downloads Android build dependencies on first sync, so internet access is needed on the computer running Android Studio.
- Do not put GitHub access tokens or other private credentials in the HTML asset.
- Test with a harmless sample HTML file before distributing the app.
